
import pandas as pd
import numpy as np
import os
from tqdm import tqdm


def bestconfig_search(file_path, budget, output_file, max_iterations=3):
    data = pd.read_csv(file_path)
    config_columns = data.columns[:-1]
    performance_column = data.columns[-1]
    system_name = os.path.basename(file_path).split('.')[0]
    maximization = False  # 所有任务均为最小化

    worst_value = data[performance_column].max() * 2
    best_performance = np.inf
    best_config = [int(np.random.choice(data[col].unique())) for col in config_columns]

    history = []

    for _ in range(budget):
        improved = False
        for i, col in enumerate(config_columns):
            best_local = None
            best_local_perf = np.inf
            for val in data[col].unique():
                candidate = best_config.copy()
                candidate[i] = val
                matched_row = data.loc[(data[config_columns] == pd.Series(candidate, index=config_columns)).all(axis=1)]
                if not matched_row.empty:
                    performance = matched_row[performance_column].iloc[0]
                else:
                    performance = worst_value
                if performance < best_local_perf:
                    best_local_perf = performance
                    best_local = val
            if best_local_perf < best_performance:
                best_config[i] = best_local
                best_performance = best_local_perf
                improved = True
        history.append(best_config + [best_performance])
        if not improved:
            break

    search_df = pd.DataFrame(history, columns=list(config_columns) + ["Performance"])
    search_df.to_csv(output_file, index=False)
    return best_config, best_performance


def main():
    datasets_folder = "datasets"
    output_folder = "search_results"
    os.makedirs(output_folder, exist_ok=True)
    budget = 100

    results = {}
    for file_name in tqdm(os.listdir(datasets_folder)):
        if file_name.endswith(".csv"):
            file_path = os.path.join(datasets_folder, file_name)
            output_file = os.path.join(output_folder, f"{file_name.split('.')[0]}_search_results.csv")
            best_solution, best_performance = bestconfig_search(file_path, budget, output_file)
            results[file_name] = {
                "Best Solution": best_solution,
                "Best Performance": best_performance
            }

    for system, result in results.items():
        print(f"System: {system}")
        print(f"  Best Solution:    [{', '.join(map(str, result['Best Solution']))}]")
        print(f"  Best Performance: {result['Best Performance']}")


if __name__ == "__main__":
    main()
