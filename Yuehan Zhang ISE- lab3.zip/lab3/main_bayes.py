
import pandas as pd
import numpy as np
import os
from skopt import gp_minimize
from skopt.space import Integer, Real
from skopt.utils import use_named_args
from tqdm import tqdm


def bayes_optimize_search(file_path, budget, output_file):
    data = pd.read_csv(file_path)
    config_columns = data.columns[:-1]
    performance_column = data.columns[-1]

    space = []
    for col in config_columns:
        values = sorted(data[col].unique())
        if all(isinstance(v, int) for v in values):
            space.append(Integer(min(values), max(values), name=col))
        else:
            space.append(Real(min(values), max(values), name=col))

    worst_value = data[performance_column].max() * 2

    @use_named_args(space)
    def objective(**params):
        sample = pd.Series(params)
        matched_row = data.loc[(data[config_columns] == sample).all(axis=1)]
        if not matched_row.empty:
            return matched_row[performance_column].iloc[0]
        else:
            return worst_value

    result = gp_minimize(objective, space, n_calls=budget, random_state=0)
    best_config = result.x
    best_perf = result.fun

    history = []
    for i in range(len(result.x_iters)):
        config = result.x_iters[i]
        perf = result.func_vals[i]
        history.append(config + [perf])

    search_df = pd.DataFrame(history, columns=list(config_columns) + ["Performance"])
    search_df.to_csv(output_file, index=False)
    return best_config, best_perf


def main():
    datasets_folder = "datasets"
    output_folder = "search_results"
    os.makedirs(output_folder, exist_ok=True)
    budget = 100

    results = {}
    for file_name in tqdm(os.listdir(datasets_folder)):
        if file_name.endswith(".csv"):
            file_path = os.path.join(datasets_folder, file_name)
            output_file = os.path.join(output_folder, f"{file_name.split('.')[0]}_search_results.csv")
            best_solution, best_performance = bayes_optimize_search(file_path, budget, output_file)
            results[file_name] = {
                "Best Solution": best_solution,
                "Best Performance": best_performance
            }

    for system, result in results.items():
        print(f"System: {system}")
        print(f"  Best Solution:    [{', '.join(map(str, result['Best Solution']))}]")
        print(f"  Best Performance: {result['Best Performance']}")


if __name__ == "__main__":
    main()
