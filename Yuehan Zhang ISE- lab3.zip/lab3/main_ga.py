
import pandas as pd
import numpy as np
import os
import random
from tqdm import tqdm


def evaluate(config, data, config_columns, performance_column, worst_value):
    matched_row = data.loc[(data[config_columns] == pd.Series(config, index=config_columns)).all(axis=1)]
    if not matched_row.empty:
        return matched_row[performance_column].iloc[0]
    else:
        return worst_value


def genetic_algorithm_search(file_path, budget, output_file, pop_size=20, generations=10, mutation_rate=0.1):
    data = pd.read_csv(file_path)
    config_columns = data.columns[:-1]
    performance_column = data.columns[-1]

    domains = [sorted(data[col].unique()) for col in config_columns]
    worst_value = data[performance_column].max() * 2

    # 初始化种群
    population = [[random.choice(dom) for dom in domains] for _ in range(pop_size)]

    history = []
    best_config = None
    best_perf = np.inf

    for _ in range(generations):
        scored = [(cfg, evaluate(cfg, data, config_columns, performance_column, worst_value)) for cfg in population]
        scored.sort(key=lambda x: x[1])
        population = [cfg for cfg, _ in scored[:pop_size // 2]]  # 选择前一半

        # 记录历史
        for cfg, perf in scored:
            history.append(cfg + [perf])
            if perf < best_perf:
                best_perf = perf
                best_config = cfg

        # 生成下一代
        next_gen = []
        while len(next_gen) < pop_size:
            parent1, parent2 = random.sample(population, 2)
            crossover_point = random.randint(1, len(config_columns) - 1)
            child = parent1[:crossover_point] + parent2[crossover_point:]

            # 变异
            if random.random() < mutation_rate:
                idx = random.randint(0, len(config_columns) - 1)
                child[idx] = random.choice(domains[idx])

            next_gen.append(child)

        population = next_gen

    # 限制最多输出budget条
    search_df = pd.DataFrame(history[:budget], columns=list(config_columns) + ["Performance"])
    search_df.to_csv(output_file, index=False)
    return best_config, best_perf


def main():
    datasets_folder = "datasets"
    output_folder = "search_results"
    os.makedirs(output_folder, exist_ok=True)
    budget = 100

    results = {}
    for file_name in tqdm(os.listdir(datasets_folder)):
        if file_name.endswith(".csv"):
            file_path = os.path.join(datasets_folder, file_name)
            output_file = os.path.join(output_folder, f"{file_name.split('.')[0]}_search_results.csv")
            best_solution, best_performance = genetic_algorithm_search(file_path, budget, output_file)
            results[file_name] = {
                "Best Solution": best_solution,
                "Best Performance": best_performance
            }

    for system, result in results.items():
        print(f"System: {system}")
        print(f"  Best Solution:    [{', '.join(map(str, result['Best Solution']))}]")
        print(f"  Best Performance: {result['Best Performance']}")


if __name__ == "__main__":
    main()
