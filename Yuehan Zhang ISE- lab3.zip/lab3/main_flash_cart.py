import pandas as pd
import numpy as np
import os
from sklearn.tree import DecisionTreeRegressor
from tqdm import tqdm

def flash_search(file_path, budget, output_file):
    data = pd.read_csv(file_path)
    config_columns = data.columns[:-1]
    performance_column = data.columns[-1]

    X = data[config_columns]
    y = data[performance_column]

    # 使用单棵决策树（CART）拟合性能函数
    model = DecisionTreeRegressor(random_state=42)
    model.fit(X, y)

    predicted = model.predict(X)
    top_indices = np.argsort(predicted)[:budget]  # 最小化目标函数

    best_config = None
    best_performance = np.inf
    history = []

    for idx in top_indices:
        config = X.iloc[idx].tolist()
        perf = y.iloc[idx]
        if perf < best_performance:
            best_performance = perf
            best_config = config
        history.append(config + [perf])

    search_df = pd.DataFrame(history, columns=list(config_columns) + ["Performance"])
    search_df.to_csv(output_file, index=False)
    return best_config, best_performance

def main():
    datasets_folder = "datasets"
    output_folder = "search_results"
    os.makedirs(output_folder, exist_ok=True)
    budget = 100

    results = {}
    for file_name in tqdm(os.listdir(datasets_folder)):
        if file_name.endswith(".csv"):
            file_path = os.path.join(datasets_folder, file_name)
            output_file = os.path.join(output_folder, f"{file_name.split('.')[0]}_search_results.csv")
            best_solution, best_performance = flash_search(file_path, budget, output_file)
            results[file_name] = {
                "Best Solution": best_solution,
                "Best Performance": best_performance
            }

    for system, result in results.items():
        print(f"System: {system}")
        print(f"  Best Solution:    [{', '.join(map(str, result['Best Solution']))}]")
        print(f"  Best Performance: {result['Best Performance']}")

if __name__ == "__main__":
    main()
