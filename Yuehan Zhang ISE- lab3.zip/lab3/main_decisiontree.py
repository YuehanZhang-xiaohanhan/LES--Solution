
import pandas as pd
import numpy as np
import os
from sklearn.tree import DecisionTreeRegressor
from tqdm import tqdm


def decision_tree_search(file_path, budget, output_file):
    data = pd.read_csv(file_path)
    config_columns = data.columns[:-1]
    performance_column = data.columns[-1]

    X = data[config_columns]
    y = data[performance_column]

    # 拟合决策树模型
    model = DecisionTreeRegressor()
    model.fit(X, y)

    # 预测所有组合的性能
    predicted = model.predict(X)
    top_indices = np.argsort(predicted)[:budget]  # 最小化问题，选前budget个预测最小的

    best_config = None
    best_performance = np.inf
    history = []

    for idx in top_indices:
        config = X.iloc[idx].tolist()
        perf = y.iloc[idx]
        if perf < best_performance:
            best_performance = perf
            best_config = config
        history.append(config + [perf])

    search_df = pd.DataFrame(history, columns=list(config_columns) + ["Performance"])
    search_df.to_csv(output_file, index=False)
    return best_config, best_performance


def main():
    datasets_folder = "datasets"
    output_folder = "search_results"
    os.makedirs(output_folder, exist_ok=True)
    budget = 100

    results = {}
    for file_name in tqdm(os.listdir(datasets_folder)):
        if file_name.endswith(".csv"):
            file_path = os.path.join(datasets_folder, file_name)
            output_file = os.path.join(output_folder, f"{file_name.split('.')[0]}_search_results.csv")
            best_solution, best_performance = decision_tree_search(file_path, budget, output_file)
            results[file_name] = {
                "Best Solution": best_solution,
                "Best Performance": best_performance
            }

    for system, result in results.items():
        print(f"System: {system}")
        print(f"  Best Solution:    [{', '.join(map(str, result['Best Solution']))}]")
        print(f"  Best Performance: {result['Best Performance']}")


if __name__ == "__main__":
    main()
